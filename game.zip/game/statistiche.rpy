python early:
    import urllib.request
    import urllib.error
    import json
    import ssl

init python:
    FIREBASE_URL = "https://firestore.googleapis.com/v1/projects/ctrlz-agli-stereotipi/databases/(default)/documents/statistiche/scelte"
    
    if not hasattr(store, 'scelte_partita'):
        scelte_partita = {}
        
    # Variabile per mostrare a schermo cosa succede con internet
    stato_firebase = "In attesa..."

    def registra_scelta(domanda_id, opzione):
        scelte_partita[domanda_id] = opzione

    def invia_e_calcola_statistiche():
        global stato_firebase
        dati_globali = {}

        # 1. Crea un bypass per i certificati SSL di Ren'Py che spesso bloccano le chiamate
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        except:
            ctx = None

        # 2. LETTURA
        try:
            req_get = urllib.request.Request(FIREBASE_URL)
            with urllib.request.urlopen(req_get, timeout=5, context=ctx) as response:
                res_json = json.loads(response.read().decode('utf-8'))
                dati_globali = res_json.get('fields', {})
                stato_firebase = "Lettura OK. "
        except urllib.error.HTTPError as e:
            stato_firebase = f"Errore Lettura: {e.code} - {e.read().decode('utf-8')}"
            print(stato_firebase)
        except Exception as e:
            stato_firebase = f"Errore di rete (Lettura): {str(e)}"
            print(stato_firebase)

        # 3. SCRITTURA
        if scelte_partita:
            nuovi_campi = {}
            for k, v in dati_globali.items():
                val_int = int(v.get('integerValue', 0))
                nuovi_campi[k] = {"integerValue": val_int}

            for dom_id, opt in scelte_partita.items():
                nome_campo = f"{dom_id}_{opt}"
                valore_vecchio = int(dati_globali.get(nome_campo, {}).get('integerValue', 0))
                nuovi_campi[nome_campo] = {"integerValue": valore_vecchio + 1}

            try:
                body = json.dumps({"fields": nuovi_campi}).encode('utf-8')
                req_patch = urllib.request.Request(
                    FIREBASE_URL,
                    data=body,
                    headers={'Content-Type': 'application/json'},
                    method='PATCH'
                )
                with urllib.request.urlopen(req_patch, timeout=5, context=ctx) as resp:
                    res_updated = json.loads(resp.read().decode('utf-8'))
                    dati_globali = res_updated.get('fields', {})
                    stato_firebase = "Connessione a Firebase riuscita!"
            except urllib.error.HTTPError as e:
                stato_firebase += f" | Errore Scrittura: {e.code} - {e.read().decode('utf-8')}"
            except Exception as e:
                stato_firebase += f" | Errore di rete (Scrittura): {str(e)}"

        scelte_partita.clear()

        # 4. CALCOLO
        percentuali = {}
        for i in range(1, 8):
            key_a = f"domanda{i}_A"
            key_b = f"domanda{i}_B"
            cnt_a = int(dati_globali.get(key_a, {}).get('integerValue', 0))
            cnt_b = int(dati_globali.get(key_b, {}).get('integerValue', 0))
            totale = cnt_a + cnt_b

            if totale > 0:
                p_a = int(round((float(cnt_a) / totale) * 100))
                p_b = 100 - p_a
            else:
                p_a, p_b = 50, 50

            percentuali[f"d{i}_A"] = p_a
            percentuali[f"d{i}_B"] = p_b

        return percentuali


# IMPORTANTE: la parola "screen" deve iniziare a inizio riga (senza spazi/rientri prima)
screen schermata_statistiche_globali(stats):
    tag menu
    modal True

    add "#0d0d1a"

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1000
        ysize 720
        background "#1a1a2e"
        padding (30, 30)

        vbox:
            spacing 15
            xalign 0.5

            text "SCELTE GLOBALI DEI GIOCATORI" size 32 color "#00ffcc" xalign 0.5 bold True
            
            # QUI VEDREMO SE C'È UN ERRORE
            #text "[stato_firebase]" size 16 color "#ffff00" xalign 0.5 bold True
            
            text "Ecco come hanno risposto gli altri giocatori:" size 18 color "#aaaaaa" xalign 0.5

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 920
                ysize 500

                vbox:
                    spacing 15

                    for i in range(1, 8):
                        $ a_val = stats.get(f"d{i}_A", 50)
                        $ b_val = stats.get(f"d{i}_B", 50)

                        frame:
                            xsize 890
                            background "#222244"
                            padding (15, 15)
                            vbox:
                                spacing 5
                                text "Domanda [i]" size 20 color "#ffffff" bold True
                                text "• Opzione A: [a_val]%" size 18 color "#00ffcc"
                                text "• Opzione B: [b_val]%" size 18 color "#ff6688"

            null height 10

            textbutton "Torna al Menu Principale":
                xalign 0.5
                action MainMenu()