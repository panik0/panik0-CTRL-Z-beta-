﻿# --- TRANSIZIONI DI SISTEMA CORRETTE ---

# Manteniamo la dissolvenza per la fine del gioco e il ritorno al menu titolo
define config.end_game_transition = fade
define config.game_main_transition = fade

# RIMUOVI o commenta con '#' queste due righe se le avevi aggiunte:
# define config.enter_transition = dissolve
# define config.exit_transition = dissolve


# Dichiarazione personaggi e immagini
define r = Character("rudy")

image bg stanza = "images/stanza.png"
image bg stanza_fin = "images/sfondo2.png"
image rudy neutral = "images/Posa4.png"
image rudy happy = "images/Posa8.png"
image rudy superhappy = "images/Posa9.png"
image rudy angry = "images/Posa3.png"
image rudy sad = "images/Posa7.png"
image rudy scared = "images/Posa5.png"
image rudy shock = "images/Posa10.png"
image rudy zooned = "images/Posa2.png"
image rudy bored = "images/Posa6.png"
image rudy closedeyes = "images/Posa12.png"
image rudy lookdown = "images/Posa11.png"
image rudy real = "images/Posa13.png"
image rudy real2 = "images/Posa14.png"
image rudy superangry = "images/Posa15.png"
image rudy final = "images/Posa16.png"


init python:
    def suona_bounce(trans, st, at):
        renpy.play("audio/bounce.ogg", channel="sound")
        return None

transform bounce:
    function suona_bounce
    pause .15
    yoffset 0
    easein .175 yoffset -10
    easeout .175 yoffset 0
    easein .175 yoffset -4
    easeout .175 yoffset 0
    yoffset 0
    repeat

transform bounce2:
    
    pause .15
    yoffset 0
    easein .175 yoffset -10
    easeout .175 yoffset 0
    easein .175 yoffset -4
    easeout .175 yoffset 0
    yoffset 0
    repeat

default good_points = 0

transform half_size:
    zoom 0.5
    xalign 0.5
    yalign 1.0


# --- INIZIO GIOCO ---
label start:
    stop music
    play music "audio/monitor.ogg" loop
    scene black with fade 

    "Mezzanotte era passata da un bel po'."
    "E la stanza era un covo di cavi e monitor."
    "Si sentiva solo il brusio dei computer."

    #stop music fadeout 1.0
    scene bg stanza with dissolve 
    play music "audio/Snowy_world_by_Kikiyama.mp3"
    show screen schermi
    
    show rudy zooned at half_size with dissolve
    pause 5.0
    show rudy shock at bounce2
    play audio "audio/bounce.ogg"
    pause 1.0
    show rudy closedeyes at half_size
    pause 1.0
    show rudy neutral at half_size

    r "Mh"
    r "Non riesco a dormire."
    show rudy bored at half_size
    r "Cosa dovrei fare?"
    
    label domanda_1:
        menu:
            "Scriverò su Character.ai, il mio chat-bot di fiducia!":
                $ registra_scelta("domanda1", "A")
                show rudy happy
                r "Si, forse mi aiuterà un po'."
                show rudy superhappy
                r "Character.ai, facciamo role-play!"

            "Mi distendo sul letto per rilassarmi":
                $ registra_scelta("domanda1", "B")
                r "Ugh! Mi gira la testa!"
                r "Mh..."
                $ good_points += 1

    show rudy lookdown at half_size
    r "Ma aspetta..."
    show rudy scared at bounce
    pause 1.0
    r "Domani ho la scuola!"
    r "Accidenti!"
    show rudy angry at half_size
    r "No, no, no! Odio andare a scuola e odio i miei compagni."
    show rudy bored
    r "Quanto vorrei non esser costretta a stare in una stanza con...loro."

    label domanda_2:
        menu:
            "In fondo... meglio la compagnia di un chat-bot":
                $ registra_scelta("domanda2", "A")
                show rudy happy 
                r "Oh si! Adoro ogni singola meccanica, meglio di una persona vera"
                r "È così bello non sentirsi giudicati"
            

            "Potrei riprovare ad avvicinarmi ai miei compagni":
                $ registra_scelta("domanda2", "B")
                show rudy neutral
                r "..."
                r "Beh, la ragazza in biblioteca sembrava simpatica"
                show rudy happy
                r "Avevamo parlato un po' di Pokèmon"
                $ good_points += 1

    show rudy real
    pause 2.5
            
    show rudy neutral at half_size
    r "Qui dentro..."
    r "Non mi ferisce nessuno, nessuno ride di me o mi ignora"
    show rudy happy
    r "Io mi trovo bene da sola"
    r "Anzi! Non sono sola, ho cosi tanti amici con me."
    r "Le chatbot non farebbero mai neanche la metà delle cattiverie che mi fanno i compagni in classe"
    
    label domanda_3:
        menu:
            "Le persone sono così noiose e crudeli senza motivo":
                $ registra_scelta("domanda3", "A")
                show rudy lookdown
                r "Ieri le mie compagne hanno riso per la mia postura storta"
                show rudy sad
                r "Sono dovuta andare in bagno per piangere"

            "Sono programmate per farlo, forse la loro ''amicizia'' non vale quanto un amico vero":
                $ registra_scelta("domanda3", "B")
                show rudy lookdown
                r "..."
                r "Ho sempre preferito un bot ad una persona..."
                show rudy neutral
                r "Ma a volte… sento l’AI come una lente sporca"
                $ good_points += 1

    show rudy lookdown at half_size
    r "Vorrei trovarmi un lavoro..."
    show rudy bored
    r "Ma CarrierMatch.ai dice che non sono abbastanza bella, non mi assumerebbe nessuno"
    
    label domanda_4:
    menu:
            "È vero, dovrei seguire le sue raccomandazioni":
                $ registra_scelta("domanda4", "A")
                r "Mi chiede sempre se voglio ricette, trucchi, consigli per sorridere di più"
                r "Mai che mi proponga qualcosa sul lavoro"
                show rudy lookdown
                r "È come se…" 
                r "la mia strada fosse già decisa..."

            "Ma non è giusto! Perché dovrei essere giudicata da una AI?!":
                $ registra_scelta("domanda4", "B")
                show rudy neutral
                r "L’algoritmo mi ha dato degli annunci"
                show rudy bored
                r "Si... per fare la baby-sitter"
                show rudy angry
                r "Ho un diploma tecnico!"
                show rudy superangry
                r "Ma sembra quasi che non ci creda!"
                $ good_points += 1

    show rudy neutral at half_size
    r "Parlare con le AI è facile. Sono sempre gentili, sempre pronte"
    r "Io invece… io no."
    r "E allora cerco di diventare come loro, docile, accomodante"
    
    label domanda_5:
        menu:
            "Così forse qualcuno mi ascolterà…":
                $ registra_scelta("domanda5", "A")
                show rudy bored
                r "Ogni giorno sento la loro voce nelle orecchie: ‘Come posso aiutarti?’ 'Posso essere d'aiuto?'"
                r "Eccetera, eccetera..."
                show rudy lookdown
                r "Ed inizio a pensare che sia questo il mio ruolo"
                r "Aiutare. Compiacere. Esistere in funzione di qualcun altro"

            "No… non deve per forza essere così!":
                $ registra_scelta("domanda5", "B")
                show rudy real
                r "..."
                show rudy real2 with dissolve
                pause 1.5
                r "Allora…"
                show rudy happy
                r "Da domani voglio essere sempre me stessa! Basta con AI e illusioni!"
                show rudy superhappy
                r "Mi comporterò come voglio io e non per fare contenti gli altri!"
                $ good_points += 1


    # --- CONTROLLO FINALE ---
    if good_points >= 5:
        jump good_final
    else:
        jump bad_final


# --- FINALE BUONO ---
label good_final:

    show rudy happy at half_size
    r "..."
    show rudy neutral
    pause 1.5
    show rudy lookdown
    r "Non... sono così sbagliata, vero?"
    
    label domanda_6:
        menu:
            "Provare a vivere non sembra una cattiva idea":
                $ registra_scelta("domanda6", "A")
                show rudy happy
                r "In effetti"
                r "Sempre meglio della amicizia finta di un chat-bot"

            "Per alcuni forse sì, per molti altri no":
                $ registra_scelta("domanda6", "B")
                show rudy neutral
                r "..."
                r "Potrei portare i miei sketchbook domani in classe..."
                show rudy happy
                r "E' da tanto che non disegno"

    jump ending


# --- FINALE CATTIVO ---
label bad_final:

    show rudy bored at half_size
    r "Già..."
    show rudy lookdown
    pause 1.5
    r "..."
    r "Sono troppo... sbagliata per gli altri?"
    
    label domanda_7:
        menu:
            "Vorrei non essere sempre io a cercare gli altri":
                $ registra_scelta("domanda7", "A")
                show rudy neutral
                r "Nessuno nemmeno si sforza di ascoltarmi..."
                r "Tanto vale stare qui."

            "Non voglio pensarci. Non mi interessa. L'unico con cui vale parlare è un chat-bot.":
                $ registra_scelta("domanda7", "B")
                show rudy neutral
                pause 1.5
                show rudy happy with dissolve
                show rudy superhappy with dissolve
                r "..."
                r "Character.ai, iniziamo una nuova avventura insieme."

    jump ending


# --- FINALE UNICO ---
# --- FINALE UNICO ---
label ending:
    
    hide screen schermi
    show bg stanza_fin with dissolve
    show rudy final at half_size with dissolve
    r "Hey..."
    r "È arrivata l'alba..."
    
    scene black with dissolve
    pause 2.0
    stop music fadeout 1.0
    play audio "audio/finale.ogg"
    
    # --- CARICAMENTO E MOSTRA STATISTICHE GLOBALI ---
label fine_gioco:
    "Grazie per aver giocato!"
    "Invio delle scelte in corso..."
    
    # Esegue l'invio e calcola le percentuali
    $ stats_totali = invia_e_calcola_statistiche()
    
    # Mostra la schermata passare la variabile stats_totali
    call screen schermata_statistiche_globali(stats=stats_totali)

    return
